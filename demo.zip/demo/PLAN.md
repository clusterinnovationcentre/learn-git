Problem statement:
We'll be creating feature flag service which will give true ro false based on the input provided and return.

This is the plan/execution order that we have to maintain
1. We need these entities
   a. FeatureFlag: fields are -> id(long primary key), name(string not null), env(string not null),  bucketId(foreign key pointing to Buckets)
    desc(string not null), createdBy(foreign key pointing to User), createdAt(timeStamp), updatedAt(timeStamp); unique index is on name,env
   b. FlagRule: fields are -> id(long primary key), FeatureFlagId(foreign key pointing to FeatureFlag), field(string not null), 
    operator(string not null), value(string not null)
   c. User : fields are -> id(uuid PK), username(unique index), type, parentUserId
   d. Buckets: fields are -> id(PK), name(not null), desc(not null), rolloutPercentage(long)
   e. UserBucket: fields are -> id(PK), BucketId(foreign key pointing to Buckets), UserId (foreign key pointing to User)
2. This is hot the flow will look like
   a. User will create user's entity using create user API 
   POST /api/v1/user
   body{userName:<>, type:GUEST/LOGGED_IN}
   b. User will create flag rule using API
   POST /api/v1/flag
   body {flagName:<>, userId:<>,env:<>, bucketId:<>(optional), rules:[{fieldName:<>, operator:<>, value:<>}]}
   c. give support to update the flag using API
   PATCH /api/v1/flag
   body {flagName:<>,userId:<>, env:<>,bucketId:<>(optional), rules:[{fieldName:<>, operator:<>, value:<>}]}
   description: only rules can ew changed flag name can not be changed, for newly added rule create new entry in
   FlagRule and for updated rule update the entry and for deleted rule delete it.
   d. to create bucket use this API
   POST /api/v1/bucket
   body:{bucketName:<>, rolloutPercentage:<1-100>}
   description: rollout percentage ca not be <1 or >100
   as soon as this api got hit a cron job will be created for let's say we ahd given 10 and rollout percentage then
   it'll fetch first 10 users from DB and pick one user randomly or if 50 was given then it will fetch 50 user and then 
   pick one user from that 
3. For evaluation flow
   a. this api will be used
   POST /api/v1/flag/evaluate
   body: {flagName:<>,userId<>, env:<>, fields: [{fieldName:<>, value:<>}]}
   description: for a given flag name it'll fetch all the rules and for each field and rule will evaluate the rule
   and if for any field we don't find rule then return false or for if any field operator gives false then reutrn false
   or else true. 
4. Logged user flow
   a. as soon as user comes to website and we don't have user if in our system or not the client will send create user 
   with type as GUST user and when the same use logs in then one more user wil be created with type as logged in
   and and in guest user's entry this parent user's id will be added.
   And then we'll cehck if the guest suer was part of any user bucket or not and if the guest user was part then we'll
   add this logged user to that same bucket
   