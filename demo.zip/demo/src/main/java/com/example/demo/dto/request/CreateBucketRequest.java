package com.example.demo.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateBucketRequest {

    @NotBlank(message = "bucketName is required")
    private String bucketName;

    @NotBlank(message = "desc is required")
    private String desc;

    @Min(value = 1, message = "rolloutPercentage must be at least 1")
    @Max(value = 100, message = "rolloutPercentage must be at most 100")
    private int rolloutPercentage;
}
