package com.example.demo.dto.response;

import com.example.demo.enums.UserType;
import lombok.Builder;
import lombok.Getter;

import java.time.Instant;
import java.util.UUID;

@Getter
@Builder
public class UserResponse {

    private UUID id;
    private String username;
    private UserType type;
    private UUID parentUserId;
    private Instant createdAt;
}
