package com.example.demo.dto.response;

import lombok.Builder;
import lombok.Getter;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Getter
@Builder
public class FlagResponse {

    private Long id;
    private String name;
    private String env;
    private String desc;
    private Long bucketId;
    private UUID createdBy;
    private UUID updatedBy;
    private Instant createdAt;
    private Instant updatedAt;
    private List<RuleResponse> rules;
}
