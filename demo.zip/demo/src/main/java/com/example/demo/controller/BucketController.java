package com.example.demo.controller;

import com.example.demo.dto.request.CreateBucketRequest;
import com.example.demo.dto.response.BucketResponse;
import com.example.demo.service.BucketService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/bucket")
@RequiredArgsConstructor
public class BucketController {

    private final BucketService bucketService;

    @PostMapping
    public ResponseEntity<BucketResponse> createBucket(@Valid @RequestBody CreateBucketRequest request) {
        BucketResponse response = bucketService.createBucket(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BucketResponse> getBucket(@PathVariable Long id) {
        return ResponseEntity.ok(bucketService.getBucketById(id));
    }
}
