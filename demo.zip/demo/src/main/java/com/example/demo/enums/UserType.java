package com.example.demo.enums;

public enum UserType {
    GUEST,
    LOGGED_IN
}
