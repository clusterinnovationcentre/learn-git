package com.example.demo.repository;

import com.example.demo.entity.User;
import com.example.demo.enums.UserType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {

    Optional<User> findByUsername(String username);

    List<User> findByType(UserType type, Pageable pageable);

    Optional<User> findByParentUserId(UUID parentUserId);
}
