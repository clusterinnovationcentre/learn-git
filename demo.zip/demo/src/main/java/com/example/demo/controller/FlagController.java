package com.example.demo.controller;

import com.example.demo.dto.request.CreateFlagRequest;
import com.example.demo.dto.request.EvaluateFlagRequest;
import com.example.demo.dto.request.UpdateFlagRequest;
import com.example.demo.dto.response.FlagResponse;
import com.example.demo.service.FlagService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/flag")
@RequiredArgsConstructor
public class FlagController {

    private final FlagService flagService;

    @PostMapping
    public ResponseEntity<FlagResponse> createFlag(@Valid @RequestBody CreateFlagRequest request) {
        FlagResponse response = flagService.createFlag(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PatchMapping
    public ResponseEntity<FlagResponse> updateFlag(@Valid @RequestBody UpdateFlagRequest request) {
        FlagResponse response = flagService.updateFlag(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/evaluate")
    public ResponseEntity<Map<String, Boolean>> evaluate(@Valid @RequestBody EvaluateFlagRequest request) {
        boolean result = flagService.evaluate(request);
        return ResponseEntity.ok(Map.of("result", result));
    }
}
