package com.example.demo.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BucketResponse {

    private Long id;
    private String name;
    private String desc;
    private int rolloutPercentage;
}
