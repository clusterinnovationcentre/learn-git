package com.example.demo.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RuleRequest {

    private Long id;

    @NotBlank(message = "fieldName is required")
    private String fieldName;

    @NotBlank(message = "operator is required")
    private String operator;

    @NotBlank(message = "value is required")
    private String value;
}
