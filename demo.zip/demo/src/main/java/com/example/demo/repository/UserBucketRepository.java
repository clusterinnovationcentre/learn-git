package com.example.demo.repository;

import com.example.demo.entity.Bucket;
import com.example.demo.entity.User;
import com.example.demo.entity.UserBucket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserBucketRepository extends JpaRepository<UserBucket, Long> {

    List<UserBucket> findByUser(User user);

    List<UserBucket> findByBucket(Bucket bucket);

    Optional<UserBucket> findByBucketAndUser(Bucket bucket, User user);

    List<UserBucket> findByUserId(UUID userId);
}
