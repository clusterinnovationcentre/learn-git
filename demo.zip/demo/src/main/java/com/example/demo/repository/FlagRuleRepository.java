package com.example.demo.repository;

import com.example.demo.entity.FeatureFlag;
import com.example.demo.entity.FlagRule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FlagRuleRepository extends JpaRepository<FlagRule, Long> {

    List<FlagRule> findByFeatureFlag(FeatureFlag featureFlag);

    void deleteByIdIn(List<Long> ids);
}
