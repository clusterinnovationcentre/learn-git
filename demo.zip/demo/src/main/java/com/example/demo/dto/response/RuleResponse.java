package com.example.demo.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class RuleResponse {

    private Long id;
    private String field;
    private String operator;
    private String value;
}
