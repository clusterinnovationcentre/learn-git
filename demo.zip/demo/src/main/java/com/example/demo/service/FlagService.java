package com.example.demo.service;

import com.example.demo.dto.request.CreateFlagRequest;
import com.example.demo.dto.request.EvaluateFlagRequest;
import com.example.demo.dto.request.RuleRequest;
import com.example.demo.dto.request.UpdateFlagRequest;
import com.example.demo.dto.response.FlagResponse;
import com.example.demo.dto.response.RuleResponse;
import com.example.demo.entity.*;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DuplicateResourceException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FlagService {

    private final FeatureFlagRepository featureFlagRepository;
    private final FlagRuleRepository flagRuleRepository;
    private final UserRepository userRepository;
    private final BucketRepository bucketRepository;
    private final UserBucketRepository userBucketRepository;

    @Transactional
    public FlagResponse createFlag(CreateFlagRequest request) {
        if (featureFlagRepository.existsByNameAndEnv(request.getFlagName(), request.getEnv())) {
            throw new DuplicateResourceException(
                    "Flag already exists: " + request.getFlagName() + " / " + request.getEnv());
        }

        User creator = resolveUser(request.getUserId());
        Bucket bucket = resolveBucket(request.getBucketId());

        FeatureFlag flag = new FeatureFlag();
        flag.setName(request.getFlagName());
        flag.setEnv(request.getEnv());
        flag.setDesc(request.getDesc());
        flag.setCreatedBy(creator);
        flag.setBucket(bucket);
        FeatureFlag saved = featureFlagRepository.save(flag);

        List<FlagRule> rules = buildRules(request.getRules(), saved);
        flagRuleRepository.saveAll(rules);

        return toResponse(saved, rules);
    }

    @Transactional
    public FlagResponse updateFlag(UpdateFlagRequest request) {
        FeatureFlag flag = featureFlagRepository.findByNameAndEnv(request.getFlagName(), request.getEnv())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Flag not found: " + request.getFlagName() + " / " + request.getEnv()));

        User updater = resolveUser(request.getUserId());
        flag.setUpdatedBy(updater);

        if (request.getBucketId() != null) {
            flag.setBucket(resolveBucket(request.getBucketId()));
        } else {
            flag.setBucket(null);
        }
        featureFlagRepository.save(flag);

        List<FlagRule> existingRules = flagRuleRepository.findByFeatureFlag(flag);
        Map<Long, FlagRule> existingById = existingRules.stream()
                .filter(r -> r.getId() != null)
                .collect(Collectors.toMap(FlagRule::getId, Function.identity()));

        Set<Long> incomingIds = request.getRules().stream()
                .map(RuleRequest::getId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        List<Long> toDelete = existingRules.stream()
                .map(FlagRule::getId)
                .filter(id -> !incomingIds.contains(id))
                .toList();

        if (!toDelete.isEmpty()) {
            flagRuleRepository.deleteByIdIn(toDelete);
        }

        List<FlagRule> upserted = new ArrayList<>();
        for (RuleRequest rr : request.getRules()) {
            FlagRule rule;
            if (rr.getId() != null && existingById.containsKey(rr.getId())) {
                rule = existingById.get(rr.getId());
            } else {
                rule = new FlagRule();
                rule.setFeatureFlag(flag);
            }
            rule.setField(rr.getFieldName());
            rule.setOperator(rr.getOperator());
            rule.setValue(rr.getValue());
            upserted.add(rule);
        }
        List<FlagRule> savedRules = flagRuleRepository.saveAll(upserted);

        return toResponse(flag, savedRules);
    }

    @Transactional(readOnly = true)
    public boolean evaluate(EvaluateFlagRequest request) {
        FeatureFlag flag = featureFlagRepository.findByNameAndEnv(request.getFlagName(), request.getEnv())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Flag not found: " + request.getFlagName() + " / " + request.getEnv()));

        User user = resolveUser(request.getUserId());

        if (flag.getBucket() != null) {
            boolean isMember = userBucketRepository
                    .findByBucketAndUser(flag.getBucket(), user)
                    .isPresent();
            if (!isMember) {
                return false;
            }
        }

        List<FlagRule> rules = flagRuleRepository.findByFeatureFlag(flag);
        Map<String, String> fieldMap = request.getFields().stream()
                .collect(Collectors.toMap(
                        EvaluateFlagRequest.FieldEntry::getFieldName,
                        EvaluateFlagRequest.FieldEntry::getValue));

        for (FlagRule rule : rules) {
            String inputValue = fieldMap.get(rule.getField());
            if (inputValue == null) {
                return false;
            }
            if (!applyOperator(rule.getOperator(), inputValue, rule.getValue())) {
                return false;
            }
        }

        return true;
    }

    private boolean applyOperator(String operator, String input, String ruleValue) {
        return switch (operator.toUpperCase()) {
            case "EQUALS" -> input.equals(ruleValue);
            case "NOT_EQUALS" -> !input.equals(ruleValue);
            case "CONTAINS" -> input.contains(ruleValue);
            case "NOT_CONTAINS" -> !input.contains(ruleValue);
            case "STARTS_WITH" -> input.startsWith(ruleValue);
            case "ENDS_WITH" -> input.endsWith(ruleValue);
            case "GT" -> parseDouble(input) > parseDouble(ruleValue);
            case "GTE" -> parseDouble(input) >= parseDouble(ruleValue);
            case "LT" -> parseDouble(input) < parseDouble(ruleValue);
            case "LTE" -> parseDouble(input) <= parseDouble(ruleValue);
            default -> throw new BadRequestException("Unsupported operator: " + operator);
        };
    }

    private double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException ex) {
            throw new BadRequestException("Numeric comparison requires numeric value, got: " + value);
        }
    }

    private User resolveUser(UUID userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));
    }

    private Bucket resolveBucket(Long bucketId) {
        if (bucketId == null) return null;
        return bucketRepository.findById(bucketId)
                .orElseThrow(() -> new ResourceNotFoundException("Bucket not found: " + bucketId));
    }

    private List<FlagRule> buildRules(List<RuleRequest> ruleRequests, FeatureFlag flag) {
        return ruleRequests.stream().map(rr -> {
            FlagRule rule = new FlagRule();
            rule.setFeatureFlag(flag);
            rule.setField(rr.getFieldName());
            rule.setOperator(rr.getOperator());
            rule.setValue(rr.getValue());
            return rule;
        }).toList();
    }

    private FlagResponse toResponse(FeatureFlag flag, List<FlagRule> rules) {
        return FlagResponse.builder()
                .id(flag.getId())
                .name(flag.getName())
                .env(flag.getEnv())
                .desc(flag.getDesc())
                .bucketId(flag.getBucket() != null ? flag.getBucket().getId() : null)
                .createdBy(flag.getCreatedBy().getId())
                .updatedBy(flag.getUpdatedBy() != null ? flag.getUpdatedBy().getId() : null)
                .createdAt(flag.getCreatedAt())
                .updatedAt(flag.getUpdatedAt())
                .rules(rules.stream().map(r -> RuleResponse.builder()
                        .id(r.getId())
                        .field(r.getField())
                        .operator(r.getOperator())
                        .value(r.getValue())
                        .build()).toList())
                .build();
    }
}
