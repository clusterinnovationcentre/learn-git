package com.example.demo.dto.request;

import com.example.demo.enums.UserType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class CreateUserRequest {

    @NotBlank(message = "username is required")
    private String userName;

    @NotNull(message = "type is required")
    private UserType type;

    private UUID guestUserId;
}
