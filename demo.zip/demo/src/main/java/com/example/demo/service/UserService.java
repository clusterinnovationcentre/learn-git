package com.example.demo.service;

import com.example.demo.dto.request.CreateUserRequest;
import com.example.demo.dto.response.UserResponse;
import com.example.demo.entity.User;
import com.example.demo.entity.UserBucket;
import com.example.demo.enums.UserType;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DuplicateResourceException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.UserBucketRepository;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final UserBucketRepository userBucketRepository;

    @Transactional
    public UserResponse createUser(CreateUserRequest request) {
        if (userRepository.findByUsername(request.getUserName()).isPresent()) {
            throw new DuplicateResourceException("Username already exists: " + request.getUserName());
        }

        if (request.getType() == UserType.LOGGED_IN) {
            return createLoggedInUser(request);
        }
        return createGuestUser(request);
    }

    private UserResponse createGuestUser(CreateUserRequest request) {
        User user = new User();
        user.setUsername(request.getUserName());
        user.setType(UserType.GUEST);
        User saved = userRepository.save(user);
        return toResponse(saved);
    }

    private UserResponse createLoggedInUser(CreateUserRequest request) {
        if (request.getGuestUserId() == null) {
            throw new BadRequestException("guestUserId is required when type is LOGGED_IN");
        }

        User guestUser = userRepository.findById(request.getGuestUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Guest user not found: " + request.getGuestUserId()));

        if (guestUser.getType() != UserType.GUEST) {
            throw new BadRequestException("Provided guestUserId does not belong to a GUEST user");
        }

        User loggedInUser = new User();
        loggedInUser.setUsername(request.getUserName());
        loggedInUser.setType(UserType.LOGGED_IN);
        User savedLoggedIn = userRepository.save(loggedInUser);

        guestUser.setParentUserId(savedLoggedIn.getId());
        userRepository.save(guestUser);

        copyBucketMemberships(guestUser, savedLoggedIn);

        return toResponse(savedLoggedIn);
    }

    private void copyBucketMemberships(User guestUser, User loggedInUser) {
        List<UserBucket> guestBuckets = userBucketRepository.findByUser(guestUser);
        List<UserBucket> copies = guestBuckets.stream()
                .map(ub -> new UserBucket(ub.getBucket(), loggedInUser))
                .toList();
        userBucketRepository.saveAll(copies);
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(UUID id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        return toResponse(user);
    }

    private UserResponse toResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .type(user.getType())
                .parentUserId(user.getParentUserId())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
