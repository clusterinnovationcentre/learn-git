package com.example.demo.repository;

import com.example.demo.entity.FeatureFlag;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FeatureFlagRepository extends JpaRepository<FeatureFlag, Long> {

    Optional<FeatureFlag> findByNameAndEnv(String name, String env);

    boolean existsByNameAndEnv(String name, String env);
}
