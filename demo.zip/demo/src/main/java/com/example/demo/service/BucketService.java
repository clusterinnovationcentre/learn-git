package com.example.demo.service;

import com.example.demo.dto.request.CreateBucketRequest;
import com.example.demo.dto.response.BucketResponse;
import com.example.demo.entity.Bucket;
import com.example.demo.entity.User;
import com.example.demo.entity.UserBucket;
import com.example.demo.enums.UserType;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.BucketRepository;
import com.example.demo.repository.UserBucketRepository;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

@Slf4j
@Service
@RequiredArgsConstructor
public class BucketService {

    private final BucketRepository bucketRepository;
    private final UserRepository userRepository;
    private final UserBucketRepository userBucketRepository;

    private final Random random = new Random();

    @Transactional
    public BucketResponse createBucket(CreateBucketRequest request) {
        Bucket bucket = new Bucket();
        bucket.setName(request.getBucketName());
        bucket.setDesc(request.getDesc());
        bucket.setRolloutPercentage(request.getRolloutPercentage());
        Bucket saved = bucketRepository.save(bucket);

        triggerRolloutJob(saved.getId(), saved.getRolloutPercentage());

        return toResponse(saved);
    }

    @Async
    public void triggerRolloutJob(Long bucketId, int rolloutPercentage) {
        try {
            Bucket bucket = bucketRepository.findById(bucketId)
                    .orElseThrow(() -> new ResourceNotFoundException("Bucket not found: " + bucketId));

            List<User> users = userRepository.findByType(
                    UserType.GUEST,
                    PageRequest.of(0, rolloutPercentage)
            );

            if (users.isEmpty()) {
                log.info("No GUEST users available for rollout on bucket {}", bucketId);
                return;
            }

            User picked = users.get(random.nextInt(users.size()));

            boolean alreadyMember = userBucketRepository.findByBucketAndUser(bucket, picked).isPresent();
            if (!alreadyMember) {
                userBucketRepository.save(new UserBucket(bucket, picked));
                log.info("Rollout job: added user {} to bucket {}", picked.getId(), bucketId);
            }
        } catch (Exception ex) {
            log.error("Rollout job failed for bucket {}: {}", bucketId, ex.getMessage(), ex);
        }
    }

    @Transactional(readOnly = true)
    public BucketResponse getBucketById(Long id) {
        Bucket bucket = bucketRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bucket not found: " + id));
        return toResponse(bucket);
    }

    private BucketResponse toResponse(Bucket bucket) {
        return BucketResponse.builder()
                .id(bucket.getId())
                .name(bucket.getName())
                .desc(bucket.getDesc())
                .rolloutPercentage(bucket.getRolloutPercentage())
                .build();
    }
}
