package com.example.demo.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
public class UpdateFlagRequest {

    @NotBlank(message = "flagName is required")
    private String flagName;

    @NotNull(message = "userId is required")
    private UUID userId;

    @NotBlank(message = "env is required")
    private String env;

    private Long bucketId;

    @NotEmpty(message = "rules must not be empty")
    @Valid
    private List<RuleRequest> rules;
}
