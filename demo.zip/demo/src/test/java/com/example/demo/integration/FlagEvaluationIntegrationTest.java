package com.example.demo.integration;

import com.example.demo.config.TestAsyncConfig;
import com.example.demo.entity.Bucket;
import com.example.demo.entity.User;
import com.example.demo.entity.UserBucket;
import com.example.demo.repository.BucketRepository;
import com.example.demo.repository.FeatureFlagRepository;
import com.example.demo.repository.FlagRuleRepository;
import com.example.demo.repository.UserBucketRepository;
import com.example.demo.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Import(TestAsyncConfig.class)
class FlagEvaluationIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BucketRepository bucketRepository;

    @Autowired
    private UserBucketRepository userBucketRepository;

    @Autowired
    private FlagRuleRepository flagRuleRepository;

    @Autowired
    private FeatureFlagRepository featureFlagRepository;

    private final List<Long> createdUserBucketIds = new ArrayList<>();
    private final List<Long> createdFlagIds = new ArrayList<>();
    private final List<Long> createdBucketIds = new ArrayList<>();

    @AfterEach
    void cleanup() {
        // Delete all UserBucket rows for created buckets (covers both manual inserts and async job inserts)
        createdBucketIds.forEach(bucketId ->
                bucketRepository.findById(bucketId).ifPresent(bucket ->
                        userBucketRepository.deleteAll(userBucketRepository.findByBucket(bucket))
                )
        );

        // Null out bucket FK on flags before deleting buckets, then delete flag + rules
        createdFlagIds.forEach(flagId ->
                featureFlagRepository.findById(flagId).ifPresent(flag -> {
                    flagRuleRepository.deleteAll(flagRuleRepository.findByFeatureFlag(flag));
                    featureFlagRepository.delete(flag);
                })
        );

        bucketRepository.deleteAllById(createdBucketIds);

        createdUserBucketIds.clear();
        createdFlagIds.clear();
        createdBucketIds.clear();
    }

    @Test
    void bucketGatedFlagEvaluation_userInBucketReturnsTrue_userNotInBucketReturnsFalse() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);

        // Step 1 & 2: Create two GUEST users
        UUID guest1Id = createUser("guest1-" + suffix, "GUEST", null);
        UUID guest2Id = createUser("guest2-" + suffix, "GUEST", null);

        // Step 3 & 4: Promote both to LOGGED_IN
        UUID user1Id = createUser("user1-" + suffix, "LOGGED_IN", guest1Id);
        UUID user2Id = createUser("user2-" + suffix, "LOGGED_IN", guest2Id);

        // Step 5: Create bucket with 100% rollout
        Long bucketId = createBucket("test-bucket-" + suffix, 100);

        // Step 6: Manually add user1 to the bucket (controlled precondition)
        User user1 = userRepository.findById(user1Id).orElseThrow();
        Bucket bucket = bucketRepository.findById(bucketId).orElseThrow();
        UserBucket userBucket = userBucketRepository.save(new UserBucket(bucket, user1));
        createdUserBucketIds.add(userBucket.getId());

        // Step 7: Create flag with bucket gate and rule: country EQUALS IN
        Long flagId = createFlag("country-flag-" + suffix, user1Id, bucketId);
        createdFlagIds.add(flagId);

        // Step 8: Evaluate for user1 (in bucket, country=IN) → expect true
        boolean resultUser1 = evaluateFlag("country-flag-" + suffix, user1Id);
        assertThat(resultUser1).isTrue();

        // Step 9: Evaluate for user2 (NOT in bucket, country=IN) → expect false
        boolean resultUser2 = evaluateFlag("country-flag-" + suffix, user2Id);
        assertThat(resultUser2).isFalse();
    }

    private UUID createUser(String username, String type, UUID guestUserId) throws Exception {
        Map<String, Object> body = new java.util.LinkedHashMap<>();
        body.put("userName", username);
        body.put("type", type);
        if (guestUserId != null) {
            body.put("guestUserId", guestUserId.toString());
        }

        MvcResult result = mockMvc.perform(post("/api/v1/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated())
                .andReturn();

        Map<?, ?> response = objectMapper.readValue(result.getResponse().getContentAsString(), Map.class);
        return UUID.fromString((String) response.get("id"));
    }

    private Long createBucket(String name, int rolloutPercentage) throws Exception {
        Map<String, Object> body = Map.of(
                "bucketName", name,
                "desc", "Integration test bucket",
                "rolloutPercentage", rolloutPercentage
        );

        MvcResult result = mockMvc.perform(post("/api/v1/bucket")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated())
                .andReturn();

        Map<?, ?> response = objectMapper.readValue(result.getResponse().getContentAsString(), Map.class);
        Long bucketId = ((Number) response.get("id")).longValue();
        createdBucketIds.add(bucketId);
        return bucketId;
    }

    private Long createFlag(String flagName, UUID userId, Long bucketId) throws Exception {
        Map<String, Object> rule = Map.of(
                "fieldName", "country",
                "operator", "EQUALS",
                "value", "IN"
        );

        Map<String, Object> body = new java.util.LinkedHashMap<>();
        body.put("flagName", flagName);
        body.put("userId", userId.toString());
        body.put("env", "prod");
        body.put("desc", "Integration test flag");
        body.put("bucketId", bucketId);
        body.put("rules", List.of(rule));

        MvcResult result = mockMvc.perform(post("/api/v1/flag")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated())
                .andReturn();

        Map<?, ?> response = objectMapper.readValue(result.getResponse().getContentAsString(), Map.class);
        return ((Number) response.get("id")).longValue();
    }

    private boolean evaluateFlag(String flagName, UUID userId) throws Exception {
        Map<String, Object> field = Map.of(
                "fieldName", "country",
                "value", "IN"
        );

        Map<String, Object> body = new java.util.LinkedHashMap<>();
        body.put("flagName", flagName);
        body.put("userId", userId.toString());
        body.put("env", "prod");
        body.put("fields", List.of(field));

        MvcResult result = mockMvc.perform(post("/api/v1/flag/evaluate")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isOk())
                .andReturn();

        Map<?, ?> response = objectMapper.readValue(result.getResponse().getContentAsString(), Map.class);
        return (Boolean) response.get("result");
    }
}
