# Feature Flag Service — Implementation Status

## Completed

### Entities (`entity/`)
- `User` — UUID PK, username (unique), type (GUEST/LOGGED_IN), parentUserId (self-ref), timestamps
- `FeatureFlag` — name+env unique, FK to Bucket (nullable), FK to User (createdBy/updatedBy), timestamps
- `FlagRule` — FK to FeatureFlag, field/operator/value as strings
- `Bucket` — name, desc, rolloutPercentage (1–100)
- `UserBucket` — FK to Bucket + User (join table)
- `UserType` enum — GUEST, LOGGED_IN

### Repositories (`repository/`)
- `UserRepository` — findByUsername, findByType (pageable), findByParentUserId
- `FeatureFlagRepository` — findByNameAndEnv, existsByNameAndEnv
- `FlagRuleRepository` — findByFeatureFlag, deleteByIdIn
- `BucketRepository` — standard CRUD
- `UserBucketRepository` — findByUser, findByBucketAndUser, findByUserId

### Exceptions (`exception/`)
- `ResourceNotFoundException` → 404
- `DuplicateResourceException` → 409
- `BadRequestException` → 400
- `GlobalExceptionHandler` — handles all above + MethodArgumentNotValidException + generic 500

### User Flow (`UserController` + `UserService`)
- `POST /api/v1/user` — creates GUEST or LOGGED_IN user
  - LOGGED_IN: requires guestUserId, links guest→loggedIn via parentUserId, copies UserBucket rows
- `GET /api/v1/user/{id}` — fetch user by UUID

### Bucket Flow (`BucketController` + `BucketService`)
- `POST /api/v1/bucket` — creates bucket, triggers @Async rollout job
  - Rollout job: fetches N GUEST users (N = rolloutPercentage), picks one randomly, inserts into UserBucket
- `GET /api/v1/bucket/{id}` — fetch bucket

### Flag CRUD + Evaluation (`FlagController` + `FlagService`)
- `POST /api/v1/flag` — creates flag + rules; validates no duplicate (name, env)
- `PATCH /api/v1/flag` — upserts rules by id; deletes rules absent from body; nullifies bucketId if absent
- `POST /api/v1/flag/evaluate` — returns `{result: true/false}`
  - Checks bucket membership if flag has bucketId
  - Evaluates each rule: EQUALS, NOT_EQUALS, CONTAINS, NOT_CONTAINS, STARTS_WITH, ENDS_WITH, GT, GTE, LT, LTE

## Decisions
- `@Async` on `BucketService.triggerRolloutJob` — fire-and-forget, errors logged not propagated
- Operator evaluation via switch on uppercase string — extensible without schema changes
- `deleteByIdIn` used for bulk rule deletion in PATCH
- `DemoApplication` scanBasePackages removed (was pointing to wrong package `com.example.test`)
